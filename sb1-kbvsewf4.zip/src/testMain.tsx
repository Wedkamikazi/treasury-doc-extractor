import { renderTestApp } from './appTest';
import './index.css';

// Render the test application
renderTestApp();